import re

def analyze_query_fast(query: str, form_of_address: str = "Sir") -> str | None:
    """
    Extremely fast rules-based NLP router.
    Intercepts simple, predictable queries and forces an immediate tool call
    or answer, bypassing the 1-2 second latency of the cloud LLM entirely.
    Returns None if the query is complex and requires full AI analysis.
    """
    q_low = query.lower().strip()
    
    # 1. Quick app launching. Let the OS resolve any installed app name.
    app_match = re.match(
        r"^(?:(?:please|can you|could you|would you)\s+)?(?:open|launch|start)\s+(?:up\s+)?(.+?)\s*[.!?]*$",
        query.strip(), re.IGNORECASE,
    )
    if app_match:
        app_name = app_match.group(1).strip().removesuffix(" please").strip()
        app_name = app_name.removeprefix("the app ").strip()
        app_name = app_name.replace('"', '').replace("'", "")
        # Immediately construct the exact tool-call string the system expects
        import json
        return f'<|tool_call>call:open_app{{"app_name": {json.dumps(app_name)}}}<tool_call|>'
        
    # 2. Weather
    if "weather" in q_low and len(q_low.split()) <= 6:
        return f'<|tool_call>call:web_search{{"query": "{query}", "mode": "search"}}<tool_call|>'

    # 3. Time / Date
    if q_low in ["what time is it", "what is the time", "current time", "time"]:
        import datetime
        now = datetime.datetime.now().strftime("%I:%M %p")
        return f"The current time is {now}, {form_of_address}."
        
    if q_low in ["what is the date", "what's the date", "date today", "what day is it"]:
        import datetime
        date = datetime.datetime.now().strftime("%A, %B %d, %Y")
        return f"Today is {date}, {form_of_address}."

    # 4. Simple Math / Calculator
    math_expr = q_low.replace("raised to", "**").replace("power", "**")
    math_expr = math_expr.replace("plus", "+").replace("minus", "-")
    math_expr = math_expr.replace("times", "*").replace("divided by", "/")
    math_expr = math_expr.replace("what is", "").replace("what's", "").replace("^", "**").strip()
    
    # Only allow safe mathematical characters
    allowed = set("0123456789+-*/.** ()")
    if math_expr and all(c in allowed for c in math_expr):
        try:
            # Safe local evaluation of simple math
            res = eval(math_expr)
            return f"That calculates to {res}, {form_of_address}."
        except Exception:
            pass

    # 5. System Status
    if q_low in ["status", "system status", "how is the system", "system load", "stats"]:
        return '<|tool_call>call:system_status{}<tool_call|>'

    # Let the LLM handle it if no quick patterns match
    return None
