"""Local, best-effort conversion of user files into bounded text context."""
from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from . import archives, documents, media, text_files, images


@lru_cache(maxsize=96)
def _cached(path_str: str, mtime_ns: int, size: int, instruction: str, analyzer_id: int) -> str:
    path = Path(path_str)
    suffix = path.suffix.lower()
    if suffix in text_files.SUPPORTED:
        return text_files.to_text(path)
    if suffix in documents.SUPPORTED:
        return documents.to_text(path)
    if suffix in media.AUDIO_SUPPORTED | media.VIDEO_SUPPORTED:
        return media.to_text(path)
    if suffix in images.SUPPORTED:
        return images.to_text(path, instruction=instruction, analyzer=_IMAGE_ANALYZERS.get(analyzer_id))
    if suffix in archives.SUPPORTED:
        return archives.to_text(path)
    return f"This file type ({suffix or 'unknown'}) has no installed local text converter."


_IMAGE_ANALYZERS: dict[int, object] = {}


def convert_file_to_text(path: str | Path, instruction: str = "", image_analyzer=None) -> str:
    """Convert common document, data, image, audio, video and archive formats.

    Conversion stays on this computer. Results are cached by file modification
    time and size, so repeated prompts avoid repeating OCR/transcription.
    """
    source = Path(path).expanduser().resolve()
    if not source.is_file():
        return "File not found or not readable."
    try:
        stat = source.stat()
        analyzer_id = id(image_analyzer) if image_analyzer else 0
        if image_analyzer:
            _IMAGE_ANALYZERS[analyzer_id] = image_analyzer
        result = _cached(str(source), stat.st_mtime_ns, stat.st_size, instruction[:500], analyzer_id)
        return (result or "No readable text was found.")[:30000]
    except Exception as exc:
        return f"Could not convert this file locally: {exc}"


__all__ = ["convert_file_to_text"]
