"""Bounded listing and text extraction for ZIP/TAR archives."""
from __future__ import annotations

from pathlib import Path
import tarfile
import gzip
import bz2
import lzma
import subprocess
import zipfile

SUPPORTED = {".zip", ".tar", ".tgz", ".gz", ".bz2", ".xz", ".rar", ".7z", ".epub"}
_TEXT_EXTENSIONS = {".txt", ".md", ".csv", ".tsv", ".json", ".yaml", ".yml", ".xml", ".html", ".xhtml", ".py", ".js", ".ts", ".css", ".sql", ".sh", ".toml", ".log", ".rtf"}


def to_text(path: Path) -> str:
    output = [f"Archive: {path.name}"]
    used = 0
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as archive:
            for info in archive.infolist()[:250]:
                output.append(info.filename)
                suffix = Path(info.filename).suffix.lower()
                if info.is_dir() or suffix not in _TEXT_EXTENSIONS or info.file_size > 100_000:
                    continue
                content = archive.read(info).decode("utf-8", errors="replace")
                section = f"\n--- {info.filename} ---\n{content[:12000]}"
                output.append(section)
                used += len(section)
                if used >= 40000:
                    break
        return "\n".join(output)
    if tarfile.is_tarfile(path):
        with tarfile.open(path, "r:*") as archive:
            for member in archive.getmembers()[:250]:
                output.append(member.name)
                if not member.isfile() or Path(member.name).suffix.lower() not in _TEXT_EXTENSIONS or member.size > 100_000:
                    continue
                stream = archive.extractfile(member)
                if stream:
                    section = f"\n--- {member.name} ---\n{stream.read(12000).decode('utf-8', errors='replace')}"
                    output.append(section)
                    used += len(section)
                    if used >= 40000:
                        break
        return "\n".join(output)
    decompressors = {".gz": gzip.open, ".bz2": bz2.open, ".xz": lzma.open}
    if path.suffix.lower() in decompressors:
        with decompressors[path.suffix.lower()](path, "rb") as stream:
            content = stream.read(500_000).decode("utf-8", errors="replace")
        return f"Compressed file contents:\n{content}"
    if path.suffix.lower() in {".rar", ".7z"}:
        import shutil
        seven_zip = shutil.which("7z") or shutil.which("7zz")
        if seven_zip:
            result = subprocess.run([seven_zip, "l", "-ba", str(path)], capture_output=True, timeout=10)
            return "Archive file listing:\n" + result.stdout.decode("utf-8", errors="replace")[:20000]
    return "This compressed archive format is not supported by the local extractor."
