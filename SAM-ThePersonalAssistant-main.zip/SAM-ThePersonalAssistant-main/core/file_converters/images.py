"""Local OCR for image attachments, with optional local-model image analysis."""
from __future__ import annotations

from pathlib import Path
import shutil
import subprocess

SUPPORTED = {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".gif", ".tif", ".tiff"}


def to_text(path: Path, instruction: str = "", analyzer=None) -> str:
    if analyzer:
        try:
            result = analyzer(path, instruction)
            if result and result.strip():
                return result
        except Exception:
            pass
    tesseract = shutil.which("tesseract")
    if tesseract:
        result = subprocess.run([tesseract, str(path), "stdout"], capture_output=True, timeout=20)
        if result.returncode == 0 and result.stdout.strip():
            return "Image text (OCR):\n" + result.stdout.decode("utf-8", errors="replace")
    return "Image text extraction needs Tesseract OCR installed, or a local vision-capable model configured. No image was sent to an online service."
