"""Plain text, source-code, structured-data and HTML readers."""
from pathlib import Path

SUPPORTED = {
    ".txt", ".md", ".rst", ".log", ".csv", ".tsv", ".json", ".yaml", ".yml",
    ".xml", ".html", ".htm", ".xhtml", ".svg", ".eml", ".py", ".js", ".ts", ".tsx", ".jsx", ".css",
    ".sql", ".sh", ".toml", ".ini", ".cfg", ".properties", ".java", ".c", ".h",
    ".cpp", ".hpp", ".cs", ".go", ".rs", ".rb", ".php", ".swift", ".kt",
    ".r", ".m", ".ps1", ".bat", ".env", ".tex", ".diff", ".patch", ".rtf",
}


def to_text(path: Path) -> str:
    raw = path.read_bytes()[:1_000_000]
    suffix = path.suffix.lower()
    text = raw.decode("utf-8-sig", errors="replace")
    if suffix in {".html", ".htm", ".xhtml"}:
        try:
            from bs4 import BeautifulSoup
            text = BeautifulSoup(text, "html.parser").get_text(" ", strip=True)
        except ImportError:
            pass
    elif suffix == ".rtf":
        import re
        text = re.sub(r"\\'[0-9a-fA-F]{2}|\\[a-zA-Z]+-?\d* ?|[{}]", " ", text)
    return text[:250_000]
