"""Offline audio/video transcription using the app's cached tiny Whisper model."""
from __future__ import annotations

from pathlib import Path
import shutil
import subprocess
import tempfile

AUDIO_SUPPORTED = {".wav", ".mp3", ".m4a", ".aac", ".ogg", ".flac", ".opus", ".wma", ".aiff", ".aif"}
VIDEO_SUPPORTED = {".mp4", ".mov", ".mkv", ".avi", ".webm", ".m4v", ".mpeg", ".mpg"}
_stt = None


def _transcriber():
    global _stt
    if _stt is None:
        from core.stt import get_whisper
        _stt = get_whisper("tiny")
    return _stt


def to_text(path: Path) -> str:
    from faster_whisper.audio import decode_audio
    audio_path = path
    temp_path = None
    if path.suffix.lower() in VIDEO_SUPPORTED:
        ffmpeg = shutil.which("ffmpeg")
        if not ffmpeg:
            return "Video transcription needs ffmpeg installed locally to extract its audio track."
        handle = tempfile.NamedTemporaryFile(suffix=".wav", delete=False)
        temp_path = Path(handle.name)
        handle.close()
        try:
            subprocess.run([ffmpeg, "-v", "error", "-i", str(path), "-vn", "-ac", "1", "-ar", "16000", "-t", "900", "-y", str(temp_path)], capture_output=True, timeout=60, check=True)
            audio_path = temp_path
        except Exception as exc:
            temp_path.unlink(missing_ok=True)
            return f"Could not extract audio from the video locally: {exc}"
    try:
        audio = decode_audio(str(audio_path), sampling_rate=16000)
        transcript = _transcriber().transcribe(audio)
        return f"Audio transcript:\n{transcript}" if transcript else "No speech was detected in the audio."
    finally:
        if temp_path:
            temp_path.unlink(missing_ok=True)
