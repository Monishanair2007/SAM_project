"""PDF and office-document text extraction without sending files to a service."""
from __future__ import annotations

from pathlib import Path
import re
import zipfile
import xml.etree.ElementTree as ET

SUPPORTED = {".pdf", ".docx", ".doc", ".pptx", ".ppt", ".xlsx", ".xls", ".odt", ".ods", ".pages"}
_NS = {"a": "http://schemas.openxmlformats.org/drawingml/2006/main", "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main"}


def _xml_text(data: bytes) -> str:
    root = ET.fromstring(data)
    return " ".join(node.text or "" for node in root.iter() if node.text)


def _docx(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        names = [n for n in archive.namelist() if n == "word/document.xml" or re.fullmatch(r"word/(header|footer)\d*\.xml", n)]
        return "\n".join(_xml_text(archive.read(name)) for name in names)


def _pptx(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        slides = sorted((n for n in archive.namelist() if re.fullmatch(r"ppt/slides/slide\d+\.xml", n)), key=lambda n: int(re.search(r"slide(\d+)", n).group(1)))
        return "\n".join(_xml_text(archive.read(name)) for name in slides)


def _xlsx(path: Path) -> str:
    with zipfile.ZipFile(path) as archive:
        shared = []
        if "xl/sharedStrings.xml" in archive.namelist():
            root = ET.fromstring(archive.read("xl/sharedStrings.xml"))
            shared = ["".join(node.text or "" for node in item.iter() if node.tag.endswith("}t")) for item in root]
        sheets = sorted((n for n in archive.namelist() if re.fullmatch(r"xl/worksheets/sheet\d+\.xml", n)), key=lambda n: int(re.search(r"sheet(\d+)", n).group(1)))
        output = []
        for sheet in sheets:
            root = ET.fromstring(archive.read(sheet))
            rows = []
            for row in root.iter():
                if not row.tag.endswith("}row"):
                    continue
                cells = []
                for cell in row:
                    if not cell.tag.endswith("}c"):
                        continue
                    value = next((node.text for node in cell if node.tag.endswith("}v")), "") or ""
                    if cell.attrib.get("t") == "s" and value.isdigit():
                        value = shared[int(value)] if int(value) < len(shared) else value
                    elif cell.attrib.get("t") == "inlineStr":
                        value = "".join(node.text or "" for node in cell.iter() if node.tag.endswith("}t"))
                    cells.append(value)
                rows.append("\t".join(cells))
            output.append("\n".join(rows))
        return "\n".join(output)


def to_text(path: Path) -> str:
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        try:
            from pypdf import PdfReader
            return "\n".join(page.extract_text() or "" for page in PdfReader(str(path)).pages[:20])
        except ImportError:
            import shutil
            import subprocess
            pdftotext = shutil.which("pdftotext")
            if pdftotext:
                result = subprocess.run([pdftotext, "-f", "1", "-l", "20", str(path), "-"], capture_output=True, timeout=15)
                if result.returncode == 0:
                    return result.stdout.decode("utf-8", errors="replace")
            raise RuntimeError("PDF reading needs pypdf installed or the pdftotext utility available locally.")
    if suffix == ".docx":
        return _docx(path)
    if suffix == ".pptx":
        return _pptx(path)
    if suffix == ".xlsx":
        return _xlsx(path)
    if suffix in {".doc", ".ppt", ".xls", ".pages"}:
        import subprocess
        import shutil
        textutil = shutil.which("textutil")
        if textutil:
            result = subprocess.run([textutil, "-convert", "txt", "-stdout", str(path)], capture_output=True, timeout=8)
            if result.returncode == 0:
                return result.stdout.decode("utf-8", errors="replace")
        soffice = shutil.which("soffice") or shutil.which("libreoffice")
        if soffice:
            import tempfile
            with tempfile.TemporaryDirectory(prefix="sam-convert-") as temp_dir:
                result = subprocess.run([soffice, "--headless", "--convert-to", "txt:Text", "--outdir", temp_dir, str(path)], capture_output=True, timeout=20)
                output = Path(temp_dir) / f"{path.stem}.txt"
                if result.returncode == 0 and output.exists():
                    return output.read_text(encoding="utf-8", errors="replace")
        raise RuntimeError("This legacy Office format needs a local converter such as LibreOffice or textutil.")
    if suffix in {".odt", ".ods"}:
        with zipfile.ZipFile(path) as archive:
            return _xml_text(archive.read("content.xml"))
    raise ValueError(f"Unsupported document type: {suffix}")
