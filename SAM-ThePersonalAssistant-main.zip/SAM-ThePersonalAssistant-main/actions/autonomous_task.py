import threading
import importlib
from core.autonomous_agent import AutonomousAgent
from core.brain_router import call_brain

def autonomous_task(args: dict) -> str:
    goal = args.get("project") or args.get("goal") or args.get("task") or "Unknown autonomous task"
    
    agent = AutonomousAgent(goal=goal)
    
    def executor(step: dict) -> str:
        tool_name = step.get("tool", "dev_agent")
        args_dict = step.get("args", {})
        try:
            mod = importlib.import_module(f"actions.{tool_name}")
            func = getattr(mod, tool_name)
            return func(args_dict)
        except Exception as e:
            raise RuntimeError(str(e))

    def run_agent():
        try:
            agent.plan(call_brain)
            agent.run(step_executor=executor)
        except Exception as e:
            print(f"[Autonomous] Task {agent.task_id} failed: {e}")

    # For multiple agents working in parallel, they just spawn in separate threads
    t = threading.Thread(target=run_agent, daemon=True)
    t.start()
    
    return f"Started overnight autonomous agent with ID: {agent.task_id}. You can spawn as many parallel agents as you want this way. Use background_monitor to check status."
