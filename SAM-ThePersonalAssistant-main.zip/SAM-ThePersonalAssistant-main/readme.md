# ⚙️ SAM
### Your Personal AI Assistant — by Nemaan Shaikh

A real-time voice AI that can hear, see, understand, and control your computer — on any OS. Supports Windows, macOS, and Linux. Built on the Gemini Live API for native audio streaming, delivering zero subscriptions and total digital autonomy.

---

## ✨ Overview

SAM is where the assistant stops being a tool and starts being a presence. It remembers yesterday's conversation, watches the topics you care about, and speaks first when it has something worth saying. The goal of this build was continuity — SAM should feel like it never fully left, even after you close it.

It's not just an assistant — it's an extension of your digital life.

---

## 🚀 Capabilities

### Core Features
| Feature | Description |
|---|---|
| 🎙️ Real-time Voice | Ultra-low latency conversation in any language via Gemini Live API |
| 🖥️ System Control | Launch apps, adjust volume/brightness, WiFi, shortcuts, power — all by voice |
| 🧩 Autonomous Tasks | High-level planning for complex multi-step goals via agent mode |
| 👁️ Visual Awareness | Real-time screen capture and webcam vision piped into your main Gemini session |
| 🧠 Persistent Memory | Deeply remembers projects, preferences, and personal context across sessions |
| ⌨️ Hybrid Input | Seamlessly switch between keyboard typing and voice commands |
| 🌅 Morning Briefing | On first boot: greets you, reads the time, recaps yesterday, and fetches live news |
| 🔔 Proactive 2.0 | Time-aware, context-aware check-ins — knows the time of day, your projects, and what you've been discussing |
| 🗓️ Session Memory | Summarises each conversation and mentions it naturally next morning — consumed after use, never repeats |
| 👁️‍🗨️ Background Monitoring | User-configured topic watching — checks for new headlines once a day and alerts naturally |
| 📊 Hardware Monitoring | Continuous CPU, RAM, GPU and temperature telemetry with localized voice alerts |
| 🌤️ Weather Report | Live weather data for your city, personalized from memory |
| 🗺️ Dynamic Content Panel | Scrollable display layer beneath the HUD that renders web results, news, and search data |
| 🔍 Multi-Mode Web Search | `news` / `research` / `price` / `compare` / `search` — Gemini Grounded first, DDG fallback |
| ⏰ Smart Reminders | OS-native scheduled notifications (Windows Task Scheduler / macOS LaunchAgent / Linux systemd) |
| ✈️ Flight Finder | Live flight price and availability lookup |
| 🎮 Game Updater | Checks and triggers game updates on Steam and Epic Games on demand |
| 📂 File Processor | Read, summarize, and answer questions about local files |
| 💻 Code Helper | Inline code review, debugging, and generation |
| 🌐 Browser Control | Open URLs, navigate tabs, and interact with the browser by voice |
| 📨 Send Message | Compose and send messages through WhatsApp, Telegram, and more |
| 🎬 YouTube Control | Search, play, and control YouTube playback by voice |
| 🖱️ Desktop Control | Taskbar, window management, and desktop-level operations |
| 🧑‍💻 Silent Language Memory | Detects spoken language on first use — all future sessions adapt automatically |
| 📱 Remote Dashboard | Control the assistant from your phone via QR code pairing |
| ⚡ Auto-Start on Boot | Registers with the OS startup system (registry / LaunchAgent / .desktop) |
| 📋 Clipboard Intelligence | Copy any text → floating panel with Translate / Summarise / Explain / Fix |
| 🎨 Assistant Customization | Change the assistant name and your name from the UI — takes effect immediately |

---

## 🆕 What's New

### 🗓️ Session Memory — SAM Remembers Yesterday
At the end of every session, SAM generates a 1-2 sentence summary of what was discussed and saves it to memory. The next morning, it's mentioned naturally in the briefing:
> *"Good morning, sir — it's 09:15. Yesterday you were working on SAM's background monitoring feature. Fetching today's headlines now."*

The summary is consumed immediately after use — it never repeats in future briefings and adds zero long-term bloat to memory.

### 👁️‍🗨️ Background Monitoring — SAM Watches While You're Away
Tell SAM to monitor any topic and it checks for new developments once a day using DuckDuckGo news. When a headline changes, it reports back naturally in your language:
> *"Efendim, takip ettiğiniz yapay zeka haberlerinde bir gelişme var: Google yeni bir model duyurdu."*

Fully opt-in — SAM monitors nothing without being explicitly asked. Crypto, financial, and trading topics are blocked at the code level regardless of what is requested. Same headline never triggers twice.

### 🔔 Proactive System 2.0 — Context-Aware, Time-Aware, Non-Repetitive
The proactive engine was rebuilt from the ground up. Instead of a generic check-in after 15 minutes of silence, SAM now:
- Knows the **time of day** — morning tone differs from evening tone
- Knows your **active projects** from memory and can ask how something is going
- Knows your **monitored topics** and can bring one up naturally
- Knows **what you were just talking about** (last 8 conversation turns)
- **Rotates** between three focus areas so it never opens with the same line twice
- Has a 20-minute cooldown (up from 10) — less intrusive, more meaningful

### 👁️ Instant Vision Acknowledgment — No More Silent Waiting
When you ask SAM to look at your screen or camera, it no longer goes silent while processing. It immediately says something natural ("Looking at your screen now, sir" / "Ekrana bakıyorum efendim") while the capture runs. The actual analysis follows as the next response.

### 📰 Parallel News Search — First Result Wins
News queries now run Gemini Grounded Search and DuckDuckGo news simultaneously in two threads. Whichever delivers a valid result first is used; the other is silently discarded. A Gemini 503 error no longer delays results — the DDG fallback is already running in parallel.

---

## 🗺️ Development History & Roadmap

Earlier development milestones (version numbers below are historical):

| Version | Focus |
|---|---|
| **XLVIII** | Instant interrupt · parallel news · two-phase briefing · exponential backoff · vision cooldown |
| **XLIX** | Auto-start · clipboard intelligence · assistant customization |
| **L** | Session memory · background monitoring · proactive 2.0 · instant vision · parallel news search |
| **LI+** | Plugin system · email · quiz mode · calorie counter · calendar |

SAM-specific work built on top of that base: rebrand to SAM (female voice, Hindi+English), hybrid Gemini/GPT-5/Hermes brain, wake word + clap-to-wake, ElevenLabs/Piper TTS, Gmail/GitHub automation, the autonomous overnight agent, the Control Center UI, and the release hardening pass — all documented in the sections above.

---

## ⚡ Quick Start

```bash
cd path/to/this/folder
python setup.py
python main.py
```

Copy `config/api_keys.example.json` to `config/api_keys.json` and add your Gemini API key before the first launch.

> ⚠️ **Installation Note:** Some OS-specific dependencies are not bundled in `requirements.txt` to keep the repo lightweight. If you hit a `ModuleNotFoundError`, install the missing package with `pip install <module_name>`.

---

## 📋 Requirements

| Requirement | Details |
| --- | --- |
| **OS** | Windows 10/11, macOS, or Linux |
| **Python** | 3.11 or 3.12 |
| **Microphone** | Required for voice interaction |
| **API Key** | Free Gemini API key (`config/api_keys.json`) |

> ⚠️ **Linux note:** Window-management features (`pygetwindow`, used by the game updater to detect running game windows) do not work on Linux at all — the `pygetwindow` library has no Linux backend. Everything else (voice, vision, system control, dashboard) works fine on Linux, but if you're on Linux and hit a `NotImplementedError` from `pygetwindow`, that's why.

---

## 🧠 Hybrid Brain (Gemini + local model, optional GPT-5)

Voice conversation always runs on Gemini Live (needs the Gemini key above). Separately, the **`agent_task`** tool — used for real coding, debugging, and multi-step planning — routes through `core/brain_router.py` to whichever brain fits the task, in this order:

1. **Gemini (primary complex brain)** — used automatically for coding/planning/research tasks. Reuses the Gemini key you already have — no extra setup, works out of the box.
2. **GPT-5 (OpenAI cloud, optional upgrade)** — only used if `openai_api_key` is set in `config/api_keys.json`. Completely optional; SAM runs fully on Gemini + your local model with no OpenAI key at all, and skips even attempting OpenAI (no wasted call) when the key isn't set.
```json
   { "openai_api_key": "sk-...", "openai_model": "gpt-5" }
```
   > OpenAI's model lineup moves fast — if `gpt-5` ever stops resolving, check the current flagship name at platform.openai.com/docs/models and update `openai_model`.
3. **Local model** — used for quick/simple commands directly, and as the last-resort fallback if Gemini/GPT-5 both fail. Two backends are supported, chosen with `"llm_provider"`:

   **LM Studio** (or any OpenAI-compatible server — Jan, LocalAI):
```json
   {
     "llm_provider": "openai",
     "llm_url": "http://localhost:1506/v1",
     "llm_model": "the-exact-model-name-shown-in-LM-Studio's-loaded-model-list"
   }
```
   `llm_url` works whether or not you include the trailing `/v1` — LM Studio's own settings screen displays it *with* `/v1`, and pasting that in verbatim is handled correctly.

   **Ollama** (Hermes or any other pulled model):
```json
   {
     "llm_provider": "ollama",
     "llm_url": "http://localhost:11434",
     "llm_model": "hermes3"
   }
```
   Requires Ollama running with a model pulled; default expected tag is `hermes3` — if yours is named differently (e.g. `hermes3:8b`), set it explicitly as shown.

   **Bionic local model:** enable Bionic's Local Model API, then set `llm_provider` to `openai`, `llm_url` to the loopback API URL shown by Bionic, and `llm_model` to the local model name. Webcam analysis supports Ollama and OpenAI-compatible local APIs, and sends frames only to `localhost`/loopback. Choose a vision-capable model; text-only models cannot analyze webcam images.

   Either way, if the configured model name isn't found, SAM logs exactly which models *are* available so you can fix the name — check the console/`logs/sam.log`.

Simple commands never touch the cloud brains at all, so nothing here adds latency to normal conversation — only `agent_task` calls route through it.

---

## 🎙️ Hybrid Voice Pipeline (wake word + TTS)

Both features below are **opt-in** — with no config changes, SAM behaves exactly as before (hot mic, Gemini's own native voice). Enable either independently by adding keys to `config/api_keys.json`.

### Wake word ("Hey Sam")
```json
{ "wake_word_enabled": true, "wake_word_threshold": 0.5 }
```
⚠️ **There is no pretrained "Hey Sam" model.** OpenWakeWord only ships `alexa`, `hey_mycroft`, `hey_jarvis`, `timer`, `weather` — nobody has trained a "Hey Sam" one. Until you do, enabling this uses **`hey_jarvis` as a placeholder** so the plumbing works end-to-end today. To get a real "Hey Sam" detector:
1. Go to **openwakeword.com/train** (hosted trainer, no GPU needed).
2. Generate + download the `.onnx` model for "Hey Sam".
3. Point SAM at it — no code changes needed:
```json
   { "wake_word_model_path": "config/hey_sam.onnx" }
```
When enabled, SAM goes back to sleep after ~15s of silence and needs the wake phrase said again — or say **"sleep"** / **"go to sleep"** any time to put it to sleep immediately, no waiting for the timeout.

### Clap-to-wake (optional, alongside wake word)
```json
{ "wake_word_enabled": true, "clap_to_wake_enabled": true }
```
Two sharp claps within ~1.5s also wakes SAM — no need to say the wake phrase. Requires `wake_word_enabled` too (clap-to-wake is an *alternate* trigger, not a replacement — there has to be something to wake *into*). This is a simple amplitude-transient detector (energy spike + fast decay), not a trained model, so it may need `clap_energy_threshold` tuned for your mic/room if it's too sensitive or not sensitive enough (default: 4000):
```json
{ "clap_energy_threshold": 4000 }
```

### TTS: ElevenLabs (primary) + Piper (offline fallback)
```json
{ "tts_engine": "hybrid", "elevenlabs_api_key": "sk_...", "tts_voice": "21m00Tcm4TlvDq8ikWAM" }
```
- `"hybrid"` (recommended): tries ElevenLabs if a key is set, automatically falls back to Piper (free, fully offline) if the key is missing or the call fails — mirrors the GPT-5/Gemini brain fallback pattern.
- `"piper"`: offline only, no key needed. First use downloads the voice model once (~60MB) from Hugging Face, then works with no internet.
- `"elevenlabs"`: cloud only, no offline fallback.
- `"gemini"` (default if unset): unchanged — Gemini Live's own native voice, exactly as it's always worked.

Known limitation: interrupting SAM mid-speech (ESC / Interrupt button) stops Gemini's own audio but doesn't yet cancel in-flight ElevenLabs/Piper playback. Worth knowing before relying on this for long responses.

---

## 📧 Gmail & GitHub Deep Automation

Beyond generic browser control, `browser_control` has purpose-built actions for Gmail and GitHub — these use your **real, already-logged-in browser profile**, so there's no separate OAuth/login flow to set up.

| Action | What it does |
| --- | --- |
| `gmail_inbox` | Reads your inbox, returns sender/subject/snippet for each email (`limit`, default 10) |
| `gmail_compose` | Opens Gmail compose, fills to/subject/body. **Never sends unless `send: true` is explicitly passed** — defaults to draft-only |
| `github_prs` | Lists pull requests for a `repo` ("owner/name"), filtered by `state` (open/closed/all) |
| `github_issues` | Same, for issues |
| `github_notifications` | Reads your GitHub notifications inbox |

⚠️ **Not verified against real accounts.** These use accessibility-role-based selectors (more stable than raw CSS classes) with a raw-text fallback if the structured extraction fails, but this was built and unit-tested against simulated page structures — not real Gmail/GitHub. If Gmail or GitHub changes their layout and something breaks, the role/aria-label selectors in `actions/browser_control.py` (`gmail_inbox`, `gmail_compose`, `_extract_list`) are the first place to check — and if structured parsing fails, you'll still get the raw page text back instead of a silent failure.

---

## 🌙 Autonomous Overnight Agent

For big unattended jobs. Say something like *"build me a CNN image classification project with a report and a PowerPoint by tomorrow morning"* and SAM plans the steps, then works through them in the background using its own tools (`dev_agent`, `browser_control`, `file_controller`, `code_helper`).

| Tool | What it does |
| --- | --- |
| `autonomous_task` | Starts a background project. Returns a `task_id` immediately; work continues in a background thread |
| `autonomous_status` | "How's the project going?" — progress, what finished, what failed |

**Survives restarts.** Progress is checkpointed to `memory/autonomous_tasks/<task_id>.json` after *every* step. If SAM or your machine restarts mid-job, resuming picks up exactly where it stopped:

## 🗂️ Project Structure
SAM/
├── main.py # Core loop — Gemini Live session, audio I/O, tool dispatch
├── ui.py # PyQt6 HUD — waveform, log panel, interrupt button, camera feed
├── setup.py # First-run configuration wizard
├── actions/
│ ├── web_search.py # Gemini + DDG parallel search (news, research, price, compare)
│ ├── screen_processor.py # Screen capture & webcam vision via Gemini Live
│ ├── background_monitor.py # User-configured topic watching — daily DDG check, no crypto
│ ├── proactive.py # Proactive 2.0 — time/context/rotation-aware check-ins
│ ├── reminder.py # OS-native scheduled notifications
│ ├── system_monitor.py # CPU / RAM / GPU / temperature telemetry
│ ├── computer_settings.py # Volume, brightness, WiFi, power
│ ├── computer_control.py # Keyboard shortcuts, mouse, window management
│ ├── open_app.py # Application launcher
│ ├── browser_control.py # Web browser control
│ ├── file_controller.py # File system operations
│ ├── file_processor.py # Document reading and summarization
│ ├── send_message.py # Messaging integration
│ ├── weather_report.py # Live weather data
│ ├── flight_finder.py # Flight search
│ ├── youtube_video.py # YouTube playback control
│ ├── game_updater.py # Game update management (Steam / Epic)
│ ├── code_helper.py # Code review and generation
│ ├── dev_agent.py # Developer task agent
│ └── desktop.py # Desktop and taskbar control
├── memory/
│ ├── memory_manager.py # Load/save long_term.json — sessions, monitors, identity
│ └── long_term.json # Persistent store: identity, preferences, projects, sessions, monitors
├── core/
│ └── prompt.txt # Assistant personality and tool-routing rules
└── config/
└── api_keys.json # API key, OS setting, assistant name, user name

---

## ⚠️ License

Personal and non-commercial use only.
Licensed under **[Creative Commons BY-NC 4.0](https://creativecommons.org/licenses/by-nc/4.0/)**.

---

## 👤 Credits

Built by **Nemaan Shaikh**.
GitHub: [Nemo1506](https://github.com/Nemo1506)

---

## ✅ Final release hardening

This release includes additional hardening on top of everything above:

- atomic, permission-restricted autonomous-task checkpoints;
- validation of autonomous plans before execution (supported tools only, bounded step count);
- path-safe autonomous task IDs to prevent checkpoint path traversal;
- a dependency-light release validator (`python validate.py`);
- dependency-light regression tests (`python tests/run_tests.py`);
- a safe `config/api_keys.example.json` template instead of shipping credentials;
- dashboard TLS certificates generated locally on first use rather than shipping a private key;
- clearer first-run setup and Python-version validation.

### Final verification

From the project root:

```bash
python validate.py
python tests/run_tests.py
python main.py
```

The first two commands do not require the full GUI/audio stack. `main.py` still requires the runtime dependencies listed in `requirements.txt`, a microphone, and a valid Gemini API key.

### Security notes

SAM is deliberately a powerful desktop assistant. Features such as computer control, browser automation, file operations, code execution, messaging, and power controls can affect the user's machine or external accounts. Keep the remote dashboard on a trusted LAN, protect the machine account, and only give SAM the permissions/accounts needed for the tasks you want it to perform.